import React, { useState, useEffect } from 'react';
import { makeStyles, Typography } from "@material-ui/core";
import axios from 'axios';

const useStyles = makeStyles({
    btnStyle: {
        background: "#3498db",
        padding: "3px 50px",
    },
    typoStyle: {
        textAlign: "left",
        padding: "30px 0px 0px 10px",
        color: "#3498db",
        fontSize: "16px",
    },
    typoStyle_logoback: {
        background: "rgb(255, 242, 243)",
    },
    typoStyle_menu: {
        color: "#fff",
        background: "#4b4b4b",
        padding: "10px 0px 5px 10px",
    },
    clearfix: {
        clear: 'both',
    },
    typoStyle_logo: {
        marginright: "280px",
        lineheight: "normal",
        float: "left",
        padding: "20px 32px",
        height: "64px",
    },
    typoStyle_table: {
        border: '1px solid',
        color: "#333",
        fontSize: "16px",
        borderColor: "#e3e7e8",
    },
    tableRow: {
      backgroundColor: 'white',
      borderColor: "#e3e7e8",
    },
    alternateRow: {
      backgroundColor: '#f5f5f5',
      borderColor: "#e3e7e8",
    },
    paperStyle: {
        background: "orange",
        height: "50px",
    },
    hoverIconStyle: {
      color: '#217dbb',
    },
});

const TableList = () => {
  const classes = useStyles();
  const [tableData, setTableData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get('http://10.2.0.31:8000/newsapi');
      setTableData(response.data.data);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <div className={classes.typoStyle_menu}>
        <Typography align='left' gutterBottom noWrap>
          News一覧 
        </Typography>
      </div>
      <div style={{ maxHeight: '900px', overflowY: 'scroll' }}>
      <table className={classes.typoStyle_table} style={{ margin: '10px 20px 10px 20px', borderCollapse: 'collapse', border: '1px solid black' }}>
        <thead>
          <tr>
            <th className={classes.typoStyle_table} style={{ padding: '8px', fontWeight: 'normal' }}>日時</th>
            <th className={classes.typoStyle_table} style={{ padding: '8px', fontWeight: 'normal' }}>タイトル</th>
            <th className={classes.typoStyle_table} style={{ padding: '8px', fontWeight: 'normal' }}>内容</th>
            <th className={classes.typoStyle_table} style={{ padding: '8px', fontWeight: 'normal' }}>URL</th>
          </tr>
        </thead>
        <tbody>
         {tableData.map((item, index) => (
          <tr key={index}>
            <td className={classes.typoStyle_table} style={{ padding: '8px' }}>{item[0]}</td>
            <td className={classes.typoStyle_table} style={{ padding: '8px' }}>{item[1]}</td>
            <td className={classes.typoStyle_table} style={{ padding: '8px' }}>{item[2]}</td>
            <td className={classes.typoStyle_table} style={{ padding: '8px' }}>{item[3]}</td>
          </tr>
         ))}
        </tbody>
      </table>
      </div>
    </div>
  );
};

export default TableList;
