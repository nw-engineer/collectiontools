import json
import sqlite3

from datetime import datetime, timedelta
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import pymysql

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

conn = sqlite3.connect("news.db", check_same_thread=False)
c = conn.cursor()

@app.get("/newsapi")
def get_search():
    c.execute("SELECT * from articles");
    data = c.fetchall()
    return {"data": data }
