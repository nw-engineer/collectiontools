import requests
import pandas as pd
import sqlite3

conn = sqlite3.connect('news.db')
cursor = conn.cursor()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS articles (
        publishedAt TEXT,
        title TEXT,
        description TEXT,
        url TEXT,
        PRIMARY KEY (publishedAt, title)
    )
''')


pd.options.display.max_colwidth = 25

headers = {'X-Api-Key': 'bbb81d19789345b0ae34a872bc46290f'}

url = 'https://newsapi.org/v2/top-headlines'
params = {
    'country': 'jp',
    'categry': 'technology',
    'pageSize': 100
}

response = requests.get(url, headers=headers, params=params)
if response.ok:
    data = response.json()
    df = pd.DataFrame(data['articles'])

    for index, row in df.iterrows():
        publishedAt = row['publishedAt']
        title = row['title']
        description = row['description']
        url = row['url']

        cursor.execute('SELECT COUNT(*) FROM articles WHERE publishedAt=? AND title=?', (publishedAt, title))
        count = cursor.fetchone()[0]

        if count == 0:
            cursor.execute('INSERT INTO articles VALUES (?, ?, ?, ?)', (publishedAt, title, description, url))

    conn.commit()
    conn.close()    
