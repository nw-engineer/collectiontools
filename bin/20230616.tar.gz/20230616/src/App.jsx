import React, { useEffect, useState } from 'react';
import { Line } from 'react-chartjs-2';
import axios from 'axios';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

const TimeSeriesChart = () => {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get('http://10.2.0.25:8000/timeseries-data');
      setData(response.data.data[0]); // 配列内のデータを取得
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  if (!data) {
    return <div>Loading data...</div>;
  }

  // データの変換とChart.jsのフォーマットへの適用
  const chartData = {
    labels: [data[0]], // 日付を配列に変換して設定
    datasets: [
      {
        label: '要素1',
        data: [data[1]], // データを配列に変換して設定
        fill: false,
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1
      },
      {
        label: '要素2',
        data: [data[2]], // データを配列に変換して設定
        fill: false,
        borderColor: 'rgb(192, 75, 192)',
        tension: 0.1
      },
      {
        label: '要素3',
        data: [data[3]], // データを配列に変換して設定
        fill: false,
        borderColor: 'rgb(192, 192, 75)',
        tension: 0.1
      },
      {
        label: '要素4',
        data: [data[4]], // データを配列に変換して設定
        fill: false,
        borderColor: 'rgb(192, 192, 75)',
        tension: 0.1
      },
    ],
    options: {
      scales: {
        x: {
          type: 'time',
          time: {
            unit: 'day'
          }
        },
        y: {
          type: 'linear'
        }
      }
    }
  };

  return <Line data={chartData} />;
};

export default TimeSeriesChart;
